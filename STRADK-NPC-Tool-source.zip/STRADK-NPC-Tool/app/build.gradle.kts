plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.stradk.npcvehicle"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.stradk.npcvehicle"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
