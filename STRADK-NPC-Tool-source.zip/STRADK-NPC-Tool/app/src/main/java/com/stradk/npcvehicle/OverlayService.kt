package com.stradk.npcvehicle

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(24, 29, 40))
        }
        val header = TextView(this).apply {
            text = "STRADK  •  NPC TOOL   [GESER]"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(4, 4, 4, 14)
        }
        val status = TextView(this).apply {
            text = "Status: siap — deteksi game belum tersedia"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(4, 4, 4, 10)
        }
        fun action(label: String, message: String) {
            val item = TextView(this).apply {
                text = label
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(12, 12, 12, 12)
                setBackgroundColor(Color.rgb(48, 65, 88))
                setOnClickListener {
                    Toast.makeText(this@OverlayService, message, Toast.LENGTH_SHORT).show()
                }
            }
            box.addView(item)
        }
        box.addView(header)
        box.addView(status)
        action("DETEKSI MOBIL NPC", "Tool demo: tidak dapat membaca kendaraan RioRise.")
        action("INTERAKSI / AMBIL MOBIL", "Gunakan hanya interaksi resmi di dalam game.")
        action("TUTUP MENU", "Floating menu ditutup.")
        box.getChildAt(box.childCount - 1).setOnClickListener { stopSelf() }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 180
        }

        header.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        wm.updateViewLayout(box, params)
                        return true
                    }
                }
                return false
            }
        })
        panel = box
        wm.addView(box, params)
    }

    override fun onDestroy() {
        panel?.let { wm.removeView(it) }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
